﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Utility
{
    public class GoogleReCaptcha
    {
        private readonly string secr_key;
        private readonly string capt_response;
        private readonly IConfiguration configuration;
        private readonly IHttpContextAccessor httpContextAccessor;

        public string ErMsg { get; set; }
        public bool IsSuccess { get; set; }

        public GoogleReCaptcha(IConfiguration configuration, IHttpContextAccessor httpContextAccessor, string secretKey = "")
        {
            this.configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;

            this.secr_key = string.IsNullOrWhiteSpace(secretKey) ? configuration["GoogleRecaptcha:SecretKey"] : secretKey;
            this.capt_response = httpContextAccessor.HttpContext.Request.Form["g-recaptcha-response"];

            var client = new WebClient();
            var reply =
                client.DownloadString(
                    string.Format("https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}", secr_key, capt_response));

            var captchaResponse = JsonConvert.DeserializeObject<CaptchaResponse>(reply);

            //when response is false check for the error message
            if (!captchaResponse.Success)
            {
                if (captchaResponse.ErrorCodes.Count <= 0) { ErMsg = "Captcha Incorrect"; }

                var error = captchaResponse.ErrorCodes[0].ToLower();
                switch (error)
                {
                    case ("missing-input-secret"):
                        ErMsg = "The secret parameter is missing.";
                        break;
                    case ("invalid-input-secret"):
                        ErMsg = "The secret parameter is invalid or malformed.";
                        break;

                    case ("missing-input-response"):
                        ErMsg = "The response parameter is missing.";
                        break;
                    case ("invalid-input-response"):
                        ErMsg = "The response parameter is invalid or malformed.";
                        break;

                    default:
                        ErMsg = "Error occured. Please try again";
                        break;
                }
                IsSuccess = false;
            }
            else
            {
                ErMsg = "";
                IsSuccess = true;
            }
        }
    }

    public class CaptchaResponse
    {
        [JsonProperty("success")]
        public bool Success { get; set; }

        [JsonProperty("error-codes")]
        public List<string> ErrorCodes { get; set; }
    }
}
