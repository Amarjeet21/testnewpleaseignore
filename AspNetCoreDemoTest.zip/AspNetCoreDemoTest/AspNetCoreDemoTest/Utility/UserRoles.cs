﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Utility
{
    public class UserRoles
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}
