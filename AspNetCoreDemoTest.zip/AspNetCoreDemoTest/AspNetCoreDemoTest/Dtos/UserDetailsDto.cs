﻿namespace AspNetCoreDemoTest.Dtos
{
    public class UserDetailsDto
    {
    }
}
