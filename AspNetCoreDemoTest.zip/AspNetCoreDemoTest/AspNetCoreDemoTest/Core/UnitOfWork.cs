﻿using AspNetCoreDemoTest.Core.Domain;
using AspNetCoreDemoTest.Core.Interface;
using System.Threading.Tasks;
namespace AspNetCoreDemoTest.Core
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context; 
        public IUserDetailsRepository UserDetails { get; set; }
        public IPageRepository Page { get; set; }
        public IContactRepository Contact { get; set; } 
        public UnitOfWork(AppDbContext context, IUserDetailsRepository UserDetailsRepository, IPageRepository PageRepository, IContactRepository contactRepository) 
        {
            _context = context;
            UserDetails = UserDetailsRepository;
            Page = PageRepository;
            Contact = contactRepository;
        }

        public int SaveChanges()
        {
            return _context.SaveChanges();
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
    }
}
