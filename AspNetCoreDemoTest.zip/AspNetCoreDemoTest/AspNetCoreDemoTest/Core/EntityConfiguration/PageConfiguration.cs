﻿using AspNetCoreDemoTest.Core.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Core.EntityConfiguration
{
    public class PageConfiguration : IEntityTypeConfiguration<Page>
    {
        public void Configure(EntityTypeBuilder<Page> builder)
        {
            builder.ToTable("Page"); //define table name

            builder.HasKey(e => e.Id); //Define primary key

            builder.Property(x => x.Id)
                .HasColumnName("Id")
                .HasColumnType("int")
                .UseIdentityColumn(1, 1) //Set Identity for this column
                .IsRequired();

            builder.Property(x => x.Slug)
               .HasColumnName("Slug")
               .HasColumnType("nvarchar(max)")             
               .IsRequired();

            builder.Property(x => x.PageTitle)
                .HasColumnName("PageTitle")
                .HasColumnType("nvarchar(max)")
                .IsRequired();

            builder.Property(x => x.Page_Content)
               .HasColumnName("Page_Content")
               .HasColumnType("nvarchar(max)")
               .IsRequired();
            builder.Property(x => x.Description)
              .HasColumnName("Description")
              .HasColumnType("nvarchar(max)")
              .IsRequired();

            builder.Property(x => x.Keywords)
            .HasColumnName("Keywords")
            .HasColumnType("nvarchar(max)")
             .IsRequired();

            builder.Property(x => x.Master_Page)
           .HasColumnName("Master_Page")
           .HasColumnType("nvarchar(max)");

            builder.Property(x => x.Meta_Tag)
           .HasColumnName("Meta_Tag")
           .HasColumnType("nvarchar(max)")
            .IsRequired(); ;

            builder.Property(x => x.IsActive)
           .HasColumnName("IsActive")
           .HasColumnType("bit")
           .HasDefaultValue(1) //our own custom value
           .IsRequired();

            builder.Property(x => x.IsDelete)
           .HasColumnName("IsDelete")
           .HasColumnType("bit")
           .HasDefaultValue(0) //our own custom value
           .IsRequired();

            builder.Property(x => x.CreatedOn)
               .HasColumnName("CreatedOn")
               .HasColumnType("datetimeoffset(7)")
               .HasDefaultValueSql("GETDATE()")
               .IsRequired();
            builder.Property(x => x.Createdby)
                .HasColumnName("Createdby")
                .HasColumnType("nvarchar(250)")
                .HasDefaultValue("Administrator")
                .IsRequired();
        }
    }
}
