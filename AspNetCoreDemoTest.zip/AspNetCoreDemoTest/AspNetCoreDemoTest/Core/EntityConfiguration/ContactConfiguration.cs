﻿using AspNetCoreDemoTest.Core.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Core.EntityConfiguration
{
    public class ContactConfiguration : IEntityTypeConfiguration<Contact>
    {
        public void Configure(EntityTypeBuilder<Contact> builder)
        {
            builder.ToTable("Contact"); //define table name

            builder.HasKey(e => e.Id); //Define primary key

            builder.Property(x => x.Id)
           .HasColumnName("Id")
           .HasColumnType("int")
           .UseIdentityColumn(1, 1) //Set Identity for this column
           .IsRequired();

            builder.Property(x => x.Name)
               .HasColumnName("Name")
               .HasColumnType("nvarchar(max)")
               .IsRequired();

            builder.Property(x => x.Email)
              .HasColumnName("Email")
              .HasColumnType("nvarchar(max)")
              .IsRequired();

            builder.Property(x => x.Phone)
             .HasColumnName("Phone")
             .HasColumnType("nvarchar(max)")
             .IsRequired();

            builder.Property(x => x.Subject)
            .HasColumnName("Subject")
            .HasColumnType("nvarchar(255)")
            .IsRequired();

            builder.Property(x => x.Message)
          .HasColumnName("Message")
          .HasColumnType("nvarchar(max)");

           builder.Property(x => x.IsActive)
          .HasColumnName("IsActive")
          .HasColumnType("bit")
          .HasDefaultValue(1) //our own custom value
          .IsRequired();

            builder.Property(x => x.IsDelete)
           .HasColumnName("IsDelete")
           .HasColumnType("bit")
           .HasDefaultValue(0) //our own custom value
           .IsRequired();

            builder.Property(x => x.CreatedOn)
               .HasColumnName("CreatedOn")
               .HasColumnType("datetimeoffset(7)")
               .HasDefaultValueSql("GETDATE()")
               .IsRequired();
            builder.Property(x => x.Createdby)
                .HasColumnName("Createdby")
                .HasColumnType("nvarchar(250)")
                .HasDefaultValue("Administrator")
                .IsRequired();


        }
    }
}
