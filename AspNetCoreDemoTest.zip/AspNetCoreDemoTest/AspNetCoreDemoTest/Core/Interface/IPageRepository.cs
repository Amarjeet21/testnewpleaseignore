﻿using AspNetCoreDemoTest.Core.Domain;
using AspNetCoreDemoTest.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Core.Interface
{
    public interface IPageRepository : IRepository<Page>
    {
        List<PageDto> GetAllPage(string searchQuery = "");

        Task<List<PageDto>> GetAllPagesAsync(string searchQuery = "");

        List<PageDto> GetPageDetailsBySlug(string slug = "");

        public Page GetBySlug(string slug = ""); 
        // Task<List<PageDto>> GetAllPagesAsync(string searchQuery = "", int page = 1, int recordPerPage = 10, string q = "", string status = ""); 
    }
}
