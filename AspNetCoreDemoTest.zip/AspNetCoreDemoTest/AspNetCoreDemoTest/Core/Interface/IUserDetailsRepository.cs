﻿using AspNetCoreDemoTest.Core.Domain;
using AspNetCoreDemoTest.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Core.Interface
{
    public interface IUserDetailsRepository : IRepository<UserDetails>
    {
        //List<UserDetailsDto> GetAllUserDetails(string searchQuery = "");
        //Task<List<UserDetailsDto>> GetAllUserDetailsAsync(string searchQuery = "");  
    }
}
