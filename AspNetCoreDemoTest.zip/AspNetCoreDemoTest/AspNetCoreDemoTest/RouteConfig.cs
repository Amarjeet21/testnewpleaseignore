﻿using Microsoft.AspNetCore.Routing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;

namespace AspNetCoreDemoTest
{
    public class RouteConfig
    {
        public static IEndpointRouteBuilder Use(IEndpointRouteBuilder route)
        {
            route.MapControllerRoute(
               name: "default",
               pattern: "{controller=Home}/{action=Index}/{id?}");

            route.MapControllerRoute("ContactThanks", "contact-thanks", new { controller = "Home", action = "ContactThanks" });

            route.MapControllerRoute("InnerPage", "{*slug}", new { controller = "Home", action = "InnerPage" });

            return route;
        }
    }
}
