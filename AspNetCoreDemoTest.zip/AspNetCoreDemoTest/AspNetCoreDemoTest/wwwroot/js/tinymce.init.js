﻿function tinymceInit(selector) {

    tinymce.init({
        selector: selector,
        menubar: false,
        height: "480",
        branding: false,
        verify_html: false,
        toolbar: 'code | bold italic underline strikethrough | forecolor backcolor |  undo redo | numlist bullist checklist | alignleft aligncenter alignright alignjustify | outdent indent | table | fontsizeselect | formatselect | a11ycheck | casechange permanentpen formatpainter removeformat | pagebreak | charmap emoticons | image media pageembed template link anchor | ltr rtl',
        //plugins: 'a11ychecker code casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinymcespellchecker',
        plugins: 'autolink lists table',
        toolbar_mode: 'floating'
    });

}

