﻿using AspNetCoreDemoTest.Core;
using AspNetCoreDemoTest.Core.Domain;
using AspNetCoreDemoTest.Models;
using AspNetCoreDemoTest.Utility;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly RoleManager<IdentityRole> roleManager;

        private readonly IConfiguration configuration;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IUnitOfWork _unitOfWork;


        public AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole> roleManager,
            IConfiguration configuration, IHttpContextAccessor httpContextAccessor, IUnitOfWork _unitOfWork)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.roleManager = roleManager;
            this.configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;
            this._unitOfWork = _unitOfWork;
        }

       
        public IActionResult Login()
        {
            var returnUrl = Request.Query["ReturnUrl"];
            if (string.IsNullOrWhiteSpace(returnUrl) || !Url.IsLocalUrl(returnUrl))
                returnUrl = "";

            ViewBag.ReturnUrl = returnUrl.ToString();

            if (User.Identity.IsAuthenticated)
                return RedirectToAction("Index", "Home");

            return View();
        }

        
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            var returnUrl = Request.Form["ReturnUrl"];
            if (string.IsNullOrWhiteSpace(returnUrl) || !Url.IsLocalUrl(returnUrl))
                returnUrl = "";

            ViewBag.ReturnUrl = returnUrl.ToString();


            if (!ModelState.IsValid)
            {
                ModelState.AddModelError("", "Fill all required fields");
                return View(model);
            }

            var user = await userManager.FindByNameAsync(model.Email);
            if (user != null && user.IsActive)
            {
                var result = await signInManager.PasswordSignInAsync(user.Email, model.Password, model.RememberMe, false);
                if (result.Succeeded)
                {
                    if (!string.IsNullOrWhiteSpace(returnUrl))
                        return LocalRedirect(returnUrl);
                    else
                        return RedirectToAction("Index", "Account");
                }
            }


            ModelState.AddModelError("", $"Username or password provided is incorrect.");
            return View(model);
        }
        //[Authorize]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError("", "Fill all required fields");
                return View(model);
            }

            //var googleReCaptcha = new GoogleReCaptcha(configuration, httpContextAccessor);
            //if (!googleReCaptcha.IsSuccess)
            //{
            //    ModelState.AddModelError("", "Verify you are not a robot!");
            //    return View(model);
            //}

            model.RoleName = UserRoles.Admin;

            var user = new ApplicationUser
            {
                ParentUserId = model.ParentUserId,
                FullName = model.FullName,
                CompanyName = string.IsNullOrWhiteSpace(model.CompanyName) ? "" : model.CompanyName,
                UserName = model.Email,
                Email = model.Email,
                PhoneNumber = model.PhoneNumber,
                ProfilePicture = "",
                IsActive = true,
                RegisterDate = DateTimeOffset.Now
            };

            var result = await userManager.CreateAsync(user, model.Password);

            if (!result.Succeeded)
            {
                ModelState.AddModelError("", String.Join("<br/>", AddErrors(result)));
                return View(model);
            }

            //add user to role
            var roleResult = await userManager.AddToRoleAsync(user, model.RoleName);

            TempData["userId"] = user.Id;
            return RedirectToAction("Thanks", "Account");
        }


        private List<string> AddErrors(IdentityResult result)
        {
            var errors = new List<string>();
            foreach (var error in result.Errors)
            {
                errors.Add(error.Description);
            }
            return errors;
        }

        public IActionResult Thanks()
        {
            if (TempData["userId"] == null)
                return RedirectToAction("Register", "Account");

            return View();
        }

        [Authorize]
        public IActionResult Index()
        {
            return View();
        }

        [Authorize, HttpPost]
        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }

        [Authorize]
        public IActionResult ManagePage(int id = 0) 
        {
            ViewBag.TinyMceEditor = configuration.GetValue<string>("TinyMceEditor") ?? "";

            PageViewModel model = new PageViewModel(); 
            var pagedata = _unitOfWork.Page.Get(id);
            if(pagedata != null)
            {
                model.Id = ViewBag.Id = pagedata.Id;
                model.Slug = ViewBag.Slug = pagedata.Slug;
                model.PageTitle = ViewBag.PageTitle = pagedata.PageTitle;
                model.Page_Content = ViewBag.Page_Content = pagedata.PageTitle;
                model.Description = ViewBag.Description = pagedata.Description;
                model.Keywords = ViewBag.Keywords = pagedata.Keywords;
                model.Meta_Tag = ViewBag.Meta_Tag = pagedata.Meta_Tag;
                
            }

            return View(model);
        }

        [Authorize,HttpPost]
        public async Task<IActionResult> ManagePage(PageViewModel model)
        {            
            var Page = new Page
            {
                Id = model.Id,
                Slug = model.Slug,
                PageTitle = model.PageTitle,                
                Page_Content = model.Page_Content,               
                Description = model.Description,               
                Keywords = model.Keywords,
                Master_Page = "1",
                Meta_Tag = model.Meta_Tag,            
                Createdby = "Administrator",
                CreatedOn = DateTime.Today
            };
            
            if (Page.Id > 0 )
                 _unitOfWork.Page.Update(Page);               
            else            
                _unitOfWork.Page.Add(Page);
           
            await _unitOfWork.SaveChangesAsync();            
            return View();
        }
        [Authorize]
        public async Task<IActionResult> ListPage()
        {          

            var Page = await _unitOfWork.Page.GetAllPagesAsync();
            return View(Page);
        }


    }
}
