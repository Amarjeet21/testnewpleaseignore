﻿using AspNetCoreDemoTest.Core;
using AspNetCoreDemoTest.Core.Domain;
using AspNetCoreDemoTest.Models;
using AspNetCoreDemoTest.Utility;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IUnitOfWork _unitOfWork;

        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IConfiguration configuration;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration, IUnitOfWork unitOfWork)
        {
            _logger = logger;
            _configuration = configuration;
            _unitOfWork = unitOfWork;
        }

        public async Task<IActionResult> Index()
       {
            //ViewBag.Email = _configuration.GetValue<string>("AddEmail") ?? "";           
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult InnerPage(string slug) 
        {

            var Page = new Page();
            var post  =  _unitOfWork.Page.GetBySlug(slug);

            if (post == null)
            {
                Response.StatusCode = 404;
                post = _unitOfWork.Page.GetBySlug("page-not-found");
                
            }
            ViewBag.post = post;
            return View();
            
        }
        public IActionResult Contact()
        {
            return View();
        }

        [HttpPost,AutoValidateAntiforgeryToken]
        public async Task<IActionResult> Contact(ContactViewModel model) 
        {
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError("", "Fill all required fields");
                return View(model);
            }

            //var googleReCaptcha = new GoogleReCaptcha(configuration, httpContextAccessor);
            //if (!googleReCaptcha.IsSuccess)
            //{
            //    ModelState.AddModelError("", "Verify you are not a robot!");
            //    return View(model);
            //}

            var user = new Contact
            {
                Name = model.Name,
                Email = model.Email,
                Subject = model.Subject,
                Phone = model.Phone,
                Message = model.Message,
                CreatedOn = DateTimeOffset.Now
            };
            _unitOfWork.Contact.Add(user);
            await _unitOfWork.SaveChangesAsync();
            return RedirectToAction("ContactThanks", "Home");
            //return View(model);
        }

        public IActionResult ContactThanks()
        {
            return View();
        }




    }
}
