﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDemoTest.Models
{
    public class ContactViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone is required")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Subject is required")]
        public string Subject { get; set; }
        public string Message { get; set; }
        public bool IsActive { get; set; }
        public bool IsDelete { get; set; }
        public DateTimeOffset CreatedOn { get; set; }
        public string Createdby { get; set; }
    }
}
